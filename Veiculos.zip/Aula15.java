







package aula15;

import java.util.Scanner;


public class Aula15 {

    
    public static int indiceCarroBarato(Veiculo carros[]){
        
        int indice=0;
        double preco;
        
        //o primeiro preco que encontra considera-se mais barato
        
        preco= carros[0].getPreco();
        
        //percorrer o array para perceber qual é o preco menor
        
        for (int i = 0; i < carros.length; i++) {
            
            if (carros[i].getPreco()<preco){
                
                // guardamos o indice
                preco = carros[i].getPreco();
                
                indice = i;
                
            }
            
        }
        
        return indice;
    }

    public static void main(String[] args) {

        //ler os dasos do teclado
        Scanner scan =  new Scanner(System.in);
        
        
        ////declarar as variaveis
        
        
        String marca;
        String modelo;
        Double preco;
        int numVeiculos;
        
        
        System.out.println("numero de veiculos ? ");
        
        numVeiculos = scan.nextInt();
        
        Veiculo carros[] = new Veiculo[numVeiculos];
        
        for (int i = 0; i < carros.length; i++) {
            
        System.out.println("caracteristicas do carro ? " + (i+1) + ":");
        System.out.println("marca ? ");
        
        marca = scan.next();
        
        System.out.println("modelo ? ");
        modelo = scan.next();
        
        System.out.println("preco ?");
        preco = scan.nextDouble();
        
        
        //cada vez que o ciclo dá uma volta guardamos o objeto
        
        carros[i] = new Veiculo(marca, modelo, preco); 
            
        }
        
        int indiceBarato = indiceCarroBarato(carros);
        
        System.out.println("o carro mais bataro é: ");
        
        System.out.println(carros[indiceBarato].getMarca());
        System.out.println(carros[indiceBarato].getModelo());
        System.out.println(carros[indiceBarato].getPreco());

          
    
        
    }
    
}
