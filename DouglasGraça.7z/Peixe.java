
package aula15;


public class Peixe extends Animal {

private String caracteristicas;

    public Peixe() {
        
        super();// chamamos o construtor dentro do construtor
        
        
        this.caracteristicas = "barbatanas e cauda";
        this.setPatas(0);// sobreescrevemos
        this.setAmbiente("mar");
        this.setCor("cinzenta");
        
        
          
        
        
    }

    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }

    @Override
            
            public String toString(){
    
    String s = super.toString();// queremos as primeiras informacoes
    s += "caracteristicas= " + caracteristicas;
    
    return s ;
    
   }



    
}
