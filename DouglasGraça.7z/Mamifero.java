
package aula15;

import java.util.logging.Logger;


public class Mamifero extends Animal {
    
    String alimento;

    public Mamifero() {
        
        super(); // chamada do construtor padrao para herdar as caracteristicas
        
        this.setAmbiente("terra");
        this.alimento = "mel";
        this.setCor("castanha");
        
        
    } 

    @Override
    public String toString() {
        
        String s = super.toString(); // caracteristicas do animal
        
    s +="\nAlimento: " + alimento;
    
        
        return s;
        
        
        
    }
    
    
    
    
   
    
    
}
